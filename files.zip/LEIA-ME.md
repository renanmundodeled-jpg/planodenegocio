# PainelPRO — Como usar

## Por que precisa do servidor?

Navegadores bloqueiam chamadas diretas a APIs externas feitas de
arquivos HTML locais (erro "Failed to fetch" / CORS). O servidor
`server.js` resolve isso fazendo a chamada pelo Node.js, que não
tem essa restrição. A chave da API fica no servidor — nunca
exposta no navegador.

---

## Requisitos

- **Node.js** instalado → https://nodejs.org (versão 14 ou superior)
- Conexão com a internet

---

## Passo a passo

### 1. Abra o terminal na pasta dos arquivos

**Windows:**
- Segure `Shift` e clique com botão direito na pasta
- Escolha "Abrir janela do PowerShell aqui" ou "Abrir no Terminal"

**Mac:**
- Clique com botão direito na pasta → "Novo Terminal na Pasta"

**Linux:**
- Clique com botão direito → "Abrir Terminal"

### 2. Execute o servidor

```
node server.js
```

Você verá:

```
  ✅ PainelPRO rodando em: http://localhost:3000
```

### 3. Abra no navegador

Acesse: **http://localhost:3000**

> ⚠️ Não abra o arquivo HTML diretamente pelo explorador de arquivos
> (file://...) — use sempre o endereço http://localhost:3000

### 4. Para encerrar

Pressione `Ctrl + C` no terminal.

---

## Arquivos necessários (mantenha na mesma pasta)

```
📁 sua-pasta/
  ├── plano_negocio_led.html   ← frontend
  ├── server.js                ← servidor proxy
  └── LEIA-ME.md               ← este arquivo
```

---

## Dúvidas comuns

**"node não é reconhecido como comando"**
→ Instale o Node.js em https://nodejs.org e reinicie o terminal.

**"Porta 3000 já está em uso"**
→ Edite a linha `const PORT = 3000;` no server.js e troque por 3001 ou 3002.

**O relatório mostra erro de cidade não encontrada**
→ Verifique o nome exato do município. Use o nome oficial (ex: "Caruaru" não "Caruaru/PE").
